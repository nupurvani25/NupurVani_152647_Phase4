package com.cg.spring.service;

import java.util.List;

import com.cg.spring.dto.Customer;

public interface IPaymentWalletService {

	public float showBalance(String mobileNumber);

	public boolean depositAmount(String mobileNumber, float amount);

	public boolean withdrawAmount(String mobileNumber, float amount);

	public boolean fundTransfer(String custMobileNo, String recvMobileNo, float amount);

	public String printTransaction(String mobileNumber);

	public boolean addWalletDetails(Customer customer);

	public List<Customer> showAllCustomers();

}
